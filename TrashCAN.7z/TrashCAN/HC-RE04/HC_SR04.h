#ifndef __HC_SR04__
#define __HC_SR04__


#include "tim.h"
#include "usart.h"
#include "gpio.h"




#define Trig_H  HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_SET)
#define Trig_L  HAL_GPIO_WritePin(Trig_GPIO_Port,Trig_Pin,GPIO_PIN_RESET)
#define Echo    HAL_GPIO_ReadPin(Echo_GPIO_Port,Echo_Pin)

unsigned int  hc_sr04(int val3);

#endif

