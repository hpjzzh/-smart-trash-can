#ifndef __HC_OPEN__
#define __HC_OPEN__

#include "tim.h"
#include "usart.h"
#include "gpio.h"

void hc_open(void );

#endif

